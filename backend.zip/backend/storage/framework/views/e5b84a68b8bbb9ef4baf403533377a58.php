<!DOCTYPE html>
<html>

<head>
    <title><?php echo e($paymentMethod); ?> Payment Notification</title>
</head>

<body>
    <h1><?php echo e($paymentMethod === 'bank' ? 'Thanh toán qua Metamask' : 'Thanh toán khi nhận hàng'); ?></h1>
    <p><?php echo e($emailContent); ?></p>
</body>

</html><?php /**PATH D:\Doan\Totnghiep\EuroMoto\backend\resources\views/emails/payment_confirmation.blade.php ENDPATH**/ ?>